/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.sql.PreparedStatement;

public class ConectarDao {

    public Connection mycon = null;
    public String sql = null;
    public PreparedStatement ps = null;

    public ConectarDao() {
        String strcon = "jdbc:mysql://localhost:3306";//cria a string de conexão ao servidor xaamp 

        try {

            mycon = DriverManager.getConnection(strcon, "root", "");
            criarBanco();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Conexão com Mysql não realizada!\n" + ex);
            //  strcon = "jdbc:mysql://localhost:3306";//cria a string de conexão ao servidor xaamp 

        }
    }

    private void criarBanco() {

        try {

            // Script 1
            sql = " CREATE DATABASE IF NOT EXISTS projcad ";
            ps = mycon.prepareStatement(sql);
            ps.execute();
            // Script 2
            ps = mycon.prepareStatement(" USE projcad ");
            ps.execute();

            sql = " CREATE TABLE IF NOT EXISTS ID ("
                    + "id int not null AUTO_INCREMENT, "
                    + "primary key (idNivel) ) ";

            ps = mycon.prepareStatement(sql);
            ps.execute();

            // Script 3
            sql = " CREATE TABLE IF NOT EXISTS USUARIOS ("
                    + "nome varchar(50) not null, "
                    + "email varchar(50) not null, "
                    + "telefone varchar(20) not null,"
                    + "primary key ( email ) )";
            ps = mycon.prepareStatement(sql);
            ps.execute();

            // Script 3
            sql = " CREATE TABLE IF NOT EXISTS PETS ("
                    + "id_ped int not null AUTO_INCREMENT, "
                    + "nome varchar (50) not null, "
                    + "especie varchar(50) not null, "
                    + "raca varchar(50) not null, "
                    + "cor varchar(20) not null,"
                    + "sit int not null, "
                    + "primary key ( id_ped ) )";
            ps = mycon.prepareStatement(sql);
            ps.execute();

            ps.close();
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, "Erro ao criar tabelas...!\n" + err.getMessage());
        }
    }

}