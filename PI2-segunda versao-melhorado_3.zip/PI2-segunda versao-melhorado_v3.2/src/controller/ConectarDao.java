/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.JOptionPane;
import java.sql.PreparedStatement;

public class ConectarDao {

    
    public String sql = null;
    public PreparedStatement ps = null;
    
    public Connection conectaBD() {
        Connection mycon = null;
        
        try {
            String url = "jdbc:mysql://localhost:3306/petlove?user=root&password=";
            mycon = DriverManager.getConnection(url);
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "ConectarDao: " + e.getMessage());
        }
        return mycon;
    }

    /*public ConectarDao() {
        String strcon = "jdbc:mysql://localhost:3306";//cria a string de conexão ao servidor xaamp 

        try {

            mycon = DriverManager.getConnection(strcon, "root", "");

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Conexão com Mysql não realizada!\n" + ex);
            //  strcon = "jdbc:mysql://localhost:3306";//cria a string de conexão ao servidor xaamp 

        }
    }*/

    

}